<?php 
    //SQL Query
    $orderID = 1;
    $total = 0;
    $getCartItems = "SELECT * FROM cartitem WHERE order_orderID = $orderID";
    $cartQuery = mysqli_query($dbc, $getCartItems);

    while ($y = mysqli_fetch_assoc($cartQuery)) {
        $getProduct = "SELECT * FROM product WHERE productID = $y[product_productID] LIMIT 1";
        $prodQuery = mysqli_query($dbc, $getProduct);
        $result = mysqli_fetch_assoc($prodQuery);
        echo "
            <div class=\"card mb-12 productCard\" style=\"max-width: 1400px;\">
                <div class=\"d-flex\">
                    <div class=\"flex-fill\">
                        <img src=\"\FMVRetro\shopping-cart\HTML\Images\games/$result[image].jpg\" alt=\"...\" class=\"productImg\">
                    </div>
                    <div class=\"flex-fill\">
                        <h5>$result[name]</h5>
                    </div>
                    <div class=\"flex-fill\">
                    <img src=\"\FMVRetro\shopping-cart\html\Images\plus.png\">  $y[quantity]  <img src=\"\FMVRetro\shopping-cart\html\Images\minus.png\">
                    </div>
                    <div class=\"flex-fill text-end\">
                        $result[price]
                    </div>
                </div>
            </div>
        ";
        $total += ($result['price'] * $y['quantity']);

    }

    echo "
    <div class=\"text-end\">
    <p>Total:        $total</p>
    </div>;
    <div class=\"text-end\">
        <p>GST/HST: 5%</p>
    </div>";
    $taxRate = 1.05;
    $total = $total * $taxRate;
    echo "<div class=\"text-end\">
        <p>Total:        $total</p>
    </div>";