<?php
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }
if (isset($_GET['userLogin']) && $_GET['userLogin'] == "true") { ?>
    <div id="loginPage"  class="vw-85 vh-75">
        <div class="row">
            <!-- Log in Section -->
            <div class="col-md-6 contentContainer" id="loginHalf">
                <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>?userLogin=true">
                    <label for="loginScreenName" class="form-label">Username</label>
                    <input type="text" class="form-control" id="usernameLogin" name="usernameLogin">
                    <br>
                    <label for="loginPassword" class="form-label">Password</label>
                    <input type="password" class="form-control" id="passwordLogin" name="passwordLogin">
                    <button type="submit" class="btn btn-primary" name="loginButton">Log In</button>
                </form>
            </div>
            <!-- Sign up Section -->
            <div class="col-md-6 contentContainer" id="signupHalf">
                <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>?userLogin=true">
                    <label for="signupScreenName">Username:</label>
                    <input type="text" class="form-control" id="usernameSignup" name="usernameSignup">
                    <label for="signupPassword">Password:</label>
                    <input type="password" class="form-control" id="passwordSignup" name="passwordSignup">
                    <label for="userEmail">E-mail:</label>
                    <input type="email" class="form-control" id="emailSignup" name="userEmail">
                    <label for="firstLastName"></label>
                    <input type="text" class="form-control" id="firstNameSignup" name="userFirstName" value="First Name">
                    <input type="text" class="form-control" id="lastNameSignup" name="userLastName" value="Last Name">
                    <label for="userAddress">Address:</label>
                    <input type="text" class="form-control" name="userAddress" id="userAddress">
                    <input type="text" class="form-control" name="userCity" id="userCity" value="City">
                    <select id="stateSignup" name="userState" class="form-control">
                        <option value="">Select One</option>
                        <optgroup label="U.S. States/Territories">
                            <option value="AK">Alaska</option>
                            <option value="AL">Alabama</option>
                            <option value="AR">Arkansas</option>
                            <option value="AZ">Arizona</option>
                            <option value="CA">California</option>
                            <option value="CO">Colorado</option>
                            <option value="CT">Connecticut</option>
                            <option value="DC">District of Columbia</option>
                            <option value="DE">Delaware</option>
                            <option value="FL">Florida</option>
                            <option value="GA">Georgia</option>
                            <option value="HI">Hawaii</option>
                            <option value="IA">Iowa</option>
                            <option value="ID">Idaho</option>
                            <option value="IL">Illinois</option>
                            <option value="IN">Indiana</option>
                            <option value="KS">Kansas</option>
                            <option value="KY">Kentucky</option>
                            <option value="LA">Louisiana</option>
                            <option value="MA">Massachusetts</option>
                            <option value="MD">Maryland</option>
                            <option value="ME">Maine</option>
                            <option value="MI">Michigan</option>
                            <option value="MN">Minnesota</option>
                            <option value="MO">Missouri</option>
                            <option value="MS">Mississippi</option>
                            <option value="MT">Montana</option>
                            <option value="NC">North Carolina</option>
                            <option value="ND">North Dakota</option>
                            <option value="NE">Nebraska</option>
                            <option value="NH">New Hampshire</option>
                            <option value="NJ">New Jersey</option>
                            <option value="NM">New Mexico</option>
                            <option value="NV">Nevada</option>
                            <option value="NY">New York</option>
                            <option value="OH">Ohio</option>
                            <option value="OK">Oklahoma</option>
                            <option value="OR">Oregon</option>
                            <option value="PA">Pennsylvania</option>
                            <option value="PR">Puerto Rico</option>
                            <option value="RI">Rhode Island</option>
                            <option value="SC">South Carolina</option>
                            <option value="SD">South Dakota</option>
                            <option value="TN">Tennessee</option>
                            <option value="TX">Texas</option>
                            <option value="UT">Utah</option>
                            <option value="VA">Virginia</option>
                            <option value="VT">Vermont</option>
                            <option value="WA">Washington</option>
                            <option value="WI">Wisconsin</option>
                            <option value="WV">West Virginia</option>
                            <option value="WY">Wyoming</option>
                        </optgroup>
                        <optgroup label="Canadian Provinces">
                            <option value="AB">Alberta</option>
                            <option value="BC">British Columbia</option>
                            <option value="MB">Manitoba</option>
                            <option value="NB">New Brunswick</option>
                            <option value="NF">Newfoundland</option>
                            <option value="NT">Northwest Territories</option>
                            <option value="NS">Nova Scotia</option>
                            <option value="NU">Nunavut</option>
                            <option value="ON">Ontario</option>
                            <option value="PE">Prince Edward Island</option>
                            <option value="QC">Quebec</option>
                            <option value="SK">Saskatchewan</option>
                            <option value="YT">Yukon Territory</option>
                        </optgroup>
                    </select>
                    <input type="text" value="Postal/Zip Code" class="form-control" id="postalCodeSignup" name="userPostal">
                    <button type="submit" class="btn btn-primary" name="createAccount">Sign Up</button>                   
                </form>
            </div>
        </div>
    </div>
    <?php } 
    //login validation
    if (isset($_POST['loginButton'])) {
        echo "<script>alert(\"Verifying Login\")</script>";
        $username = $_POST['usernameLogin'];
        $password = base64_encode($_POST['passwordLogin']);
        //user login query
        $findUser = "SELECT * FROM `user` WHERE `userName` = '$username'";
        echo $findUser;
        $loginQuery = mysqli_query($dbc, $findUser);
        if (mysqli_num_rows($loginQuery) > 0) {
            while ($y = mysqli_fetch_assoc($loginQuery)) {
                if ($password == $y['password']) {
                    //SESSION VARIABLES 
                    $_SESSION['username'] = $y['userName'];
                    $_SESSION['userID'] = $y['userID'];
                    $_SESSION['login'] = true;
                    //Detect if user is Admin
                    if ($y['accountStatus'] == "Admin") {
                        $_SESSION['admin'] = true;
                    }
                    //Detect if there is an open cart
                    $userID = $_SESSION['userID'];
                    $getCart = "SELECT * FROM `order` WHERE `user_userID` = $userID AND `status` = 'OPEN'";
                    echo $getCart;
                    $cartQuery = mysqli_query($dbc, $getCart);
                    if (mysqli_num_rows($cartQuery) == 1) {
                        while ($y = mysqli_fetch_assoc($cartQuery)) {
                            //Store cart ID in session variable
                            $_SESSION['orderID'] = $y['orderID'];
                        }
                    }
                    elseif (mysqli_num_rows($cartQuery) > 1) {
                        echo "ERROR LOADING CART, PLEASE CONTACT ADMINISTRATOR";
                    }
                    echo "Sign in Successful!";
                }
                else {
                    //invalid password
                    echo "<script>alert(\"Invalid Password!\");</script>";
                }
            }
        }
        else {
            //invalid username
            echo "<script>alert(\"Username not found, please create an account\");</script>";
        }
        ?>
        <!-- Refresh Page -->
        <script type="text/javascript">
            window.location.href ='<?php echo $_SERVER['PHP_SELF']; ?>';
        </script>
        <?php
    }
    if (isset($_POST['createAccount'])) {
        //Form Validation
        $validForm = true;

        //username validation
        if (empty($_POST['usernameSignup'])) {
            echo "<script>alert(\"Please enter a username\");</script>";
            $validForm = false;
        }
        else {
            $username = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['usernameSignup'])));
        }

        //password validation
        if (empty($_POST['passwordSignup'])) {
            echo "<script>alert(\"Please enter a password\");</script>";
            $validForm = false;
        }
        elseif (strlen($_POST['passwordSignup']) < 6) {
            echo "<script>alert(\"Please choose a password with at least 6 characters\");</script>";
            $validForm = false;
        }
        else {
            $password = base64_encode(mysqli_real_escape_string($dbc, trim(strip_tags($_POST['passwordSignup']))));
        }

        //user name validation
        if (empty($_POST['userFirstName'])) {
            echo "<script>alert(\"Please enter a first name\");</script>";
            $validForm = false;
        }
        else {
            $firstName = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['userFirstName'])));
        }

        //last name
        if (empty($_POST['userLastName'])) {
            echo "<script>alert(\"Please enter a last name\");</script>";
            $validForm = false;
        }
        else {
            $lastName = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['userLastName'])));
        }

        //user address validation
        if (empty($_POST['userAddress'])) {
            echo "<script>alert(\"Please enter an address\");</script>";
            $validForm = false;
        }
        else {
            $address = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['userAddress'])));
        }

        //city validation
        if (empty($_POST['userCity'])) {
            echo "<script>alert(\"Please enter a city\");</script>";
            $validForm = false;
        }
        else {
            $city = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['userCity'])));
        }
        //email validation
        $email = test_input($_POST["userEmail"]);
        if (empty($_POST['userEmail'])) {
            echo "<script>alert(\"Please enter an e-mail address\");</script>";
            $validForm = false;
        }
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
            $validForm = false;
              }
        else {
                $email = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['userEmail'])));
            }
        //postal/zip code validation
        if (empty($_POST['userPostal'])) {
            echo "<script>alert(\"Please enter an e-mail address\");</script>";
            $validForm = false;
        }
        else {
            $postalRegex = '/^[ABCEGHJKLMNPRSTVXY]{1}\d{1}[A-Z]{1} *\d{1}[A-Z]{1}\d{1}$/';
            $zipRegex = '/^[0-9]{5}(?:-[0-9]{4})?$/';
            if (preg_match($postalRegex, $_POST['userPostal']) == 1 || preg_match($zipRegex, $_POST['userPostal']) == 1) {
                $postalCode = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['userPostal'])));
            }
            else {
                echo "<script>alert(\"Invalid Zip/Postal Code\");</script>";
                $validForm = false;
            }
        }
        //Province/State Validation
        if ($_POST['userState'] != "") {
            $province = $_POST['userState'];
        }
        else {
            echo "<script>alert(\"Invalid State/Province\");</script>";
            $validForm = false;
        }
        if ($validForm) {
            $addUser = "INSERT INTO `user`(`firstName`, `lastName`, `userName`, `password`, `address`, `city`, `province`, `postalCode`, `accountStatus`, `creationDate`, `email`) VALUES ('$firstName','$lastName','$username','$password','$address','$city','$province','$postalCode','Customer',SYSDATE(),'$email')";

            $checkUser = "SELECT * FROM `user`";
            $runCheck = mysqli_query($dbc, $checkUser);
            //Check that username or email aren't already stored in DB
            while ($y = mysqli_fetch_assoc($runCheck)) {
                if ($username == $y['userName']) {
                    echo "<script>alert(\"That user name is already taken\")</script>";
                    $validForm = false;
                }
                elseif ($email == $y['email']) {
                    echo "<script>alert(\"That email address has already been used.\")</script>";
                    $validForm = false;
                }
            }
            //Add new user is all validation is passed

                $runUserQuery = mysqli_query($dbc, $addUser);
                echo "<script>alert(\"User has been added.\")</script>";
            }
        }
    
    
    
    
    
    
    ?>


