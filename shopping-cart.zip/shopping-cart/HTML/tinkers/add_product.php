<?php mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); ?>
<html>
<head>
<title>Add Products | FMV Co.</title>
</head>
<body>
<?php

	$hostname = 'localhost';
	$user = 'root';
	$pswd = '';
	$db = 'fmvretro';
	$dbc = mysqli_connect($hostname, $user, $pswd, $db);

	//If block adds product data into the product table


		//$id = mysqli_real_escape_string($dbc, trim(strip_tags(strtoupper($_POST['prodID']))));
		$name = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['prodName'])));
		$price = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['prodPrice'])));
		$description = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['prodDescription'])));
		$image = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['prodImage'])));
		$stock = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['prodStock'])));
		$genre = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['prodGenre'])));
		$console = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['prodConsole'])));
		//$query = "INSERT INTO product VALUES ('$id', '$name', '$price', '$description', '$image', '$stock', '$genre', '$console')";
		
		//Add product
		$addProduct = "INSERT INTO product (`name`, price, `description`, `image`, stock, genre_genreID, console_consoleID) VALUES ('$name', $price, '$description', '$image', $stock, $genre, $console)";
		echo $addProduct;
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$target_dir = "/FMVRetro/shopping-cart/HTML/images/games/";
			$target_file = $target_dir . basename($_FILES["prodImage"]["name"]);
			$uploadOk = 1;
			$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
			// Check if image file is a actual image or fake image
			if(isset($_POST["save"])) {
				$check = getimagesize($_FILES["prodImage"]["tmp_name"]);
					if($check !== false) {
						echo "File is an image - " . $check["mime"] . ".";
						$uploadOk = 1;
					} 
					else {
						echo "File is not an image.";
						$uploadOk = 0;
					}
			}
			// Check if file already exists
			if (file_exists($target_file)) {
				echo "Sorry, file already exists.";
				$uploadOk = 0;
			}
			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				echo "Sorry, your file was not uploaded.";
			// if everything is ok, try to upload file
			} else {
				if (move_uploaded_file($_FILES["prodImage"]["tmp_name"], $target_file)) {
				echo "The file ". htmlspecialchars( basename( $_FILES["prodImage"]["name"])). " has been uploaded.";
				} 
				else {
				echo "Sorry, there was an error uploading your file.";
				}
			}
		}
		//alerts admin if insert completed or not
		if (!mysqli_query($dbc, $addProduct)){
			?> <script> alert("Unable to add product"); </script><?php
		} else {
			?> <script> alert("Product sucessfully added"); </script><?php
		}
	
	//Console select
	$consoleList = "SELECT `consoleID`, `consoleName` FROM `console`";

	//Genre select
	$genreList = "SELECT * FROM genre";

	
?>



	<!--Form allows admin to enter the product information -->
	<form action="add_product.php" method="POST" enctype="multipart/form-data">
		<p> Name: <br><input type="text" name="prodName" /></p>
		<p> Price: <br><input type="text" name="prodPrice" /></p>
		<p> Description: <br><textarea name="prodDescription" required maxlength="500" minlength="1"  rows="10" cols="50"></textarea></p>
		<p> Image: <br><input type="file" name="prodImage" accept=".jpg, .jpeg, .png" /></p>
		<p> Stock: <br><input type="number" name="prodStock" /></p>
	<?php

		function selectRow ($value, $id) {
			echo "<option value =\"$id\">$value</option>";
		}
	?>
	
 
	Select Console: <select name="prodConsole" id="consoleSelector">
	<?php
	  $consoleQuery = mysqli_query($dbc, $consoleList);
	  while ($y = mysqli_fetch_array($consoleQuery)) {
		  selectRow($y['consoleName'], $y['consoleID']);
	  }
  	?>
		</select>
		<br>Select Genre <select name="prodGenre" id="genreSelector">
		<?php
			$genreQuery = mysqli_query($dbc, $genreList);
			while ($y = mysqli_fetch_array($genreQuery)) {
				selectRow($y['genreName'], $y['genreID']);
				
			}
		?>
		</select>
 
		<br><br>
		<input type="submit" value="save" />
	</form>

<?php
	mysqli_close($dbc);
?>

</body>
</html>