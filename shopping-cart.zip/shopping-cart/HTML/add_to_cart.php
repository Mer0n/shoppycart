<?php

//Basic SQL connection
$hostname = 'localhost';
$user = 'root';
$pswd = 'Xx4O.calxX';
$db = 'fmvretro';
$dbc = mysqli_connect($hostname, $user, $pswd, $db);

// Get POST vars
$order_id = $_POST['order_id'];
$product_id = $_POST['product_id'];
$user_id = $_POST['user_id'];
$quantity = $_POST['quantity'];

// Queries
$getCart = "SELECT * FROM `order` WHERE user_userID='$user_id' AND status='OPEN'";
$getProductPrice = "SELECT price,stock FROM product WHERE productID = '$product_id'";
$createCart = "INSERT INTO `order` (`user_userID`, `status`) VALUES ($user_id, 'OPEN')";
$updateProductStock = "UPDATE product SET stock=stock-1  WHERE productID = '$product_id'";

// Get price
$priceQuery = mysqli_query($dbc, $getProductPrice);
if ($priceQuery) {
    $query =  mysqli_fetch_array($priceQuery);
    $price = $query[0];
    $currentStock =$query[1];
} else { echo 'Price query error'; }

// Get cart
$cart = mysqli_query($dbc, $getCart);

if ($cart && $currentStock > 0) {
    // If cart not found, create a new one
    if (mysqli_num_rows($cart) == 0) {
        mysqli_query($dbc, $createCart);
    }

    $itemExist = "SELECT quantity FROM cartitem where order_orderID=$order_id and product_productID=$product_id";
    echo $itemExist;
    $quantityQuery = mysqli_query($dbc, $itemExist);

    if (mysqli_num_rows($quantityQuery) > 0) {
        $quantity = mysqli_fetch_array($quantityQuery)[0] + 1;
        $updateCartItem = "UPDATE cartitem SET quantity=$quantity where order_orderID=$order_id and product_productID=$product_id";
         if(mysqli_query($dbc, $updateCartItem)) {
            mysqli_query($dbc, $updateProductStock);
         };

    } else {
        $addCartItem = "
            INSERT INTO `cartitem` (`order_orderID`, `product_productID`, `quantity`, `paidPrice`)
            VALUES ($order_id, $product_id, $quantity, $price)";

        // Add item
        if (mysqli_query($dbc, $addCartItem)) {
            mysqli_query($dbc, $updateProductStock);
            echo 'Success';
        } else {
            echo 'Error';
        }
    }

} else {
    printf('error', mysqli_error($dbc));
}

