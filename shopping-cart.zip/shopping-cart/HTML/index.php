
<?php
    session_start();
    include ("connect.inc.php");
?>
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- BootStrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous"> 
    <!-- JQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link href="style/style.css" rel="stylesheet">
    <title></title>
</head>
<body>
    <!--Header-->
<!-- TODO: Find font -->
<!-- TODO: Make site logo -->
    <nav class="navbar navbar-expand-lg" id="headerNav">
            <div class="container-fluid">
              <a class="navbar-brand" href="index.php">FMVRetro Games</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#" id="find">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" tabindex="-1" aria-disabled="true" id="order">About</a>
                    </li>
                    <li class="nav-item">
<!-- TODO: Implement Drop-down menu-->
                        <a class="nav-link" href="?productPage=true" tabindex="-1" aria-disabled="true" id="games">Games</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" tabindex="-1" aria-disabled="true" id="confirm">Contact</a>
                    </li>
                    <?php if (isset ($_SESSION['admin']) && $_SESSION['admin']) {
                        ?>
                        <li class="nav-item">
                        <a class="nav-link" href="?add_product=true" tabindex="-1" aria-disabled="true" id="confirm">Add Product</a>
                    </li>    
                    <?php } ?>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
<!-- TODO: Implement drop-down menu after user has signed in-->
                        <?php 
                        if (!isset ($_SESSION['userID'])) {
                            echo "
                            <a class=\"nav-link\" href=\"?userLogin=true\" tabindex=\"-1\" aria-disabled=\"true\" id=\"confirm\">Sign-in</a>";
                        }
                        else {
                            echo "<a class=\"nav-link\" href=\"?logout=true\" tabindex=\"-1\" aria-disabled=\"true\" id=\"confirm\">" . $_SESSION['username'] . "</a>";
                        } ?>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-auto" href="?displayCart=true" tabindex="-1" aria-disabled="true" id="confirm">Cart</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <?php
        if (isset($_SESSION['username'])) {
            echo "Welcome " . $_SESSION['username'];
        }
    ?>
    <!--Login/Registration Section-->
    <?php
        if (isset($_GET['userLogin']) && $_GET['userLogin'] == "true") { ?>
    <div id="login">

        <!-- TODO: Implement User Login/Registration -->
        <?php include ("login.php"); ?>
    </div>
    <?php };?>
    
    <!-- Admin Section -->
    <?php
    if (isset($_GET['add_product']) && $_GET['add_product'] == "true") { ?>
    <div id="add_product">
        <div id="addProduct">
            <!-- TODO: Implement section to add products to database -->
            <?php include ("add_product.php"); ?>
        </div>
    </div> 
    <?php }; ?>

    <!--Product Page Section-->
    <?php
    if (isset($_GET['productPage']) && $_GET['productPage'] == "true") { ?>
    <div id="productPage"  class="vw-85 vh-75">
        <div class="row">
            <div class="col-md-12 contentContainer">
        <!-- TODO: Implement Product Page -->
        <?php 
            include ("productPage.php");
        ?>
            </div>
        </div>

    </div>
    <?php }; ?>



    <!--About Page Section-->
    <div id="aboutPage">
        <!-- TODO: Implement About Page -->
    </div>

    <!--Contact Page Section-->
    <div id="contactPage">
        <!-- TODO: Implement Shopping Cart -->
    </div>

    <!--Shopping Cart-->
    <div id="shoppingCart">
        <!-- TODO: Implement Shopping Cart -->
        <?php
            if (isset($_GET['displayCart']) && $_GET['displayCart'] == "true") { ?>
            <div id="cartDisplay"  class="vw-85 vh-75">
                <!-- TODO: Implement Product Page -->
                <?php 
                    include ("cartDisplay.php");
                ?>
            </div>
        <?php }; ?>
    </div>

    <!-- User Profile -->
    <div id="userProfile">
        <!-- TODO: Implement user profile page -->
    </div>

    <!-- User Order History -->
    <div id="orderHistory">
        <!-- TODO: Implement Order History page -->
    </div>


    <!--Footer-->
    <!-- TODO: Finish footer -->
    <footer class="footer">
        <div class="container text-center">
            <span class="text-muted">Footer Text</span>
        </div>
    </footer>
    <?php
    //logout
    if (isset($_GET['logout']) && $_GET['logout']) {
        session_destroy();
        ?>
        <script type="text/javascript">
            window.location.href ='<?php echo $_SERVER['PHP_SELF']; ?>';
        </script>
        <?php
    }
    ?>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
</body>
</html>
