<?php mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); ?>
<html>
<head>
	<title>Add Products | FMV Co.</title>
</head>
<body>
	
	<div id="addProductForm" class="d-flex justify-content-center">
		<?php

			$hostname = 'localhost';
			$user = 'root';
			$pswd = 'Xx4O.calxX';
			$db = 'fmvretro';
			$dbc = mysqli_connect($hostname, $user, $pswd, $db);

			$formName = $_POST['prodName'] ?? '0';
			$nameQuery = "SELECT * from product WHERE name='$formName'";
			$nameResult = mysqli_query($dbc, $nameQuery);

			//If block adds product data into the product table if there are no duplicates
			if ($_SERVER['REQUEST_METHOD'] == 'POST' && mysqli_num_rows($nameResult) == 0) {
				//$id = mysqli_real_escape_string($dbc, trim(strip_tags(strtoupper($_POST['prodID']))));
				$name = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['prodName'])));
				$price = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['prodPrice'])));
				$description = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['prodDescription'])));
				$image = mysqli_real_escape_string($dbc, trim(strip_tags($_FILES["prodImage"]["name"])));
				$image = explode(".", $image)[0];
				$stock = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['prodStock'])));
				$genre = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['prodGenre'])));
				$console = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['prodConsole'])));
				$releaseYear = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['releaseYear'])));
// 				$query = "INSERT INTO product VALUES ('$id', '$name', '$price', '$description', '$image', '$stock', '$genre', '$console')";
				$publisher = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['publisher'])));
				//Add product
				$addProduct = "INSERT INTO product (`name`, price, `description`, `image`, stock, genre_genreID, console_consoleID, releaseYear, publisher) VALUES ('$name', $price, '$description', '$image', $stock, $genre, $console, $releaseYear, '$publisher')";

				$target_dir = "images/games/";
				$target_file = $target_dir . basename($_FILES["prodImage"]["name"]);
				$uploadOk = 1;
				$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
				// Check if image file is an actual image or fake image
				if(isset($_POST["submit"])) {
					$check = getimagesize($_FILES["prodImage"]["tmp_name"]);
					if($check !== false) {
						echo "File is an image - " . $check["mime"] . ".";
						$uploadOk = 1;
					} else {
						echo "File is not an image.";
						$uploadOk = 0;
					}
				}

				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
					echo "Sorry, your file was not uploaded.";
				// if everything is ok, try to upload file
				} else {
					if (move_uploaded_file($_FILES["prodImage"]["tmp_name"], $target_file)) {
						echo "The file ". htmlspecialchars( basename( $_FILES["prodImage"]["name"])). " has been uploaded.";
					} else {
						echo "Sorry, there was an error uploading your file.";
					}
				}

				//alerts admin if insert completed or not
				if (!mysqli_query($dbc, $addProduct)){
					?> <script> alert("Unable to add product"); </script><?php
				} else {
					?> <script> alert("Product sucessfully added"); </script><?php
				}
			} else if (mysqli_num_rows($nameResult) > 0) {
				echo "name is already taken";
			}
			//Console select
			$consoleList = "SELECT `consoleID`, `consoleName` FROM `console`";

			//Genre select
			$genreList = "SELECT * FROM genre";


		?>

			<!--Form allows admin to enter the product information -->
			<form action="<?php echo $_SERVER['PHP_SELF']; ?>?add_product=true" method="POST" enctype="multipart/form-data">
				<!--<p> ID: <br><input type="text" name="prodID" required/></p>-->
				<p> Name: <br><input type="text" name="prodName" required/></p>
				<p> Release Year: <br><input type="text" name="releaseYear" required/></p>
				<p> Publisher: <br><input type="text" name="publisher" required/></p>
				<p> Price: <br><input type="text" name="prodPrice" required/></p>
				<p> Description: <br><textarea name="prodDescription" required maxlength="500" minlength="1"  rows="10" cols="50"></textarea></p>
				<p> Image: <br><input type="file" name="prodImage" required/></p>
				<p> Stock: <br><input type="number" name="prodStock" required/></p>
			<?php

				function selectRow ($value, $id) {
					echo "<option value =\"$id\">$value</option>";
				}
			?>


			<p class="addProductForm">Filter by Console: </p><select name="prodConsole" id="consoleSelector">
			<?php
			$consoleQuery = mysqli_query($dbc, $consoleList);
			while ($y = mysqli_fetch_array($consoleQuery)) {
				selectRow($y['consoleName'], $y['consoleID']);
			}
			?>
				</select>
				<p class="addProductForm">AND/OR by Genre </p><select name="prodGenre" id="genreSelector">
				<?php
					$genreQuery = mysqli_query($dbc, $genreList);
					while ($y = mysqli_fetch_array($genreQuery)) {
						selectRow($y['genreName'], $y['genreID']);

					}
				?>
				</select>

				<br><br>
				<input type="submit" value="save" />
			</form>
	</div>

	<?php
		mysqli_close($dbc);
	?>

</body>
</html>
