<?php

include ("connect.inc.php");

?>


<?php
    //Console select
	$consoleList = "SELECT `consoleID`, `consoleName` FROM `console`";

	//Genre select
	$genreList = "SELECT * FROM genre";

    //Function creates option tags for DB entries for genre and console selection
    function selectRow ($value, $id) {

      echo "<option value =\"$id\">$value</option>";

    }
?>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
Filter by Console: <select name="consoleSelector" id="consoleSelector"> <option value="null">All</option>
<?php
echo 'console'. $consoleList;
    $consoleQuery = mysqli_query($dbc, $consoleList);
    while ($y = mysqli_fetch_array($consoleQuery)) {
        selectRow($y['consoleName'], $y['consoleID']);
    }
//
//     echo "test test";
?>
</select>
AND/OR by Genre <select name="genreSelector" id="genreSelector"><option value="null">All</option>
<?php
    $genreQuery = mysqli_query($dbc, $genreList);
    while ($y = mysqli_fetch_array($genreQuery)) {
        selectRow($y['genreName'], $y['genreID']);

    }
?>
</select>
<button type="submit" id="filterBtn" formmethod="post" formaction="<?php echo $_SERVER['PHP_SELF']; ?>?productPage=true">Filter Products</button>
</form>
<?php

//only genre is selected
if (isset($_POST['genreSelector']) && $_POST['consoleSelector'] == "null" && $_POST['genreSelector'] != "null") {
    $chosenGenre = $_POST['genreSelector'];
    $genreSelect = "SELECT * FROM product WHERE genre_genreID = $chosenGenre";
    $genreSelectResult = mysqli_query($dbc, $genreSelect);
    while ($y = mysqli_fetch_assoc($genreSelectResult)) {
        echo "
        <div class=\"card mb-12\ productCard\" style=\"max-width: 1400px;\">
            <div class=\"row g-0\">
                <div class=\"col-md-5\">
                    <img src=\"\FMVRetro\shopping-cart\html\Images\games/$y[image].jpg\" alt=\"...\" class=\"productImg\">
                </div>
                <div class=\"col-md-6\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\">$y[name] - $y[releaseYear]</h5>
                        <p class=\"card-text\">$y[price]</p>
                        <p class=\"card-text\">$y[console_consoleID] - $y[genre_genreID]</p>
                        <p class=\"card-text\">$y[description]</p>
                    </div>
                </div>
                <div class=\"col-md-1\">
                    <button class=\"add_to_cart genre\">Add to Cart</button>
                </div>
            </div>
        </div>
        ";
    }
}
//only console is selected
elseif (isset($_POST['consoleSelector']) && $_POST['genreSelector'] == "null" && $_POST['consoleSelector'] != "null") {
    $chosenConsole = $_POST['consoleSelector'];
    $consoleSelect = "SELECT * FROM product WHERE console_consoleID = $chosenConsole";
    $consoleSelectResult = mysqli_query($dbc, $consoleSelect);
    while ($y = mysqli_fetch_assoc($consoleSelectResult)) {
        echo "
        <div class=\"card mb-12\ productCard\" style=\"max-width: 1400px;\">
            <div class=\"row g-0\">
                <div class=\"col-md-5\">
                    <img src=\"\FMVRetro\shopping-cart\html\Images\games/$y[image].jpg\" alt=\"...\" class=\"productImg\">
                </div>
                <div class=\"col-md-6\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\">$y[name] - $y[releaseYear]</h5>
                        <p class=\"card-text\">$y[price]</p>
                        <p class=\"card-text\">$y[console_consoleID] - $y[genre_genreID]</p>
                        <p class=\"card-text\">$y[description]</p>
                    </div>
                </div>
                <div class=\"col-md-1\">
                    <button class=\"add_to_cart console\" >Add to Cart</button>
                </div>
            </div>
        </div>
        ";

    }
}
//both are selected
elseif (isset($_POST['genreSelector']) && isset($_POST['consoleSelector']) && $_POST['consoleSelector'] != "null") {
   echo "both";
    $chosenGenre = $_POST['genreSelector'];
    echo "genre ".$chosenGenre;
    $chosenConsole = $_POST['consoleSelector'];
    echo "console ".$chosenConsole;
    $dualSelect = "SELECT * FROM product WHERE console_consoleID = $chosenConsole AND genre_genreID = $chosenGenre";
    $dualSelectResult = mysqli_query($dbc, $dualSelect);
    while ($y = mysqli_fetch_array($dualSelectResult)) {
        echo "
        <div class=\"card mb-12\ productCard\" style=\"max-width: 1400px;\">
            <div class=\"row g-0\">
                <div class=\"col-md-5\">
                    <img src=\"\FMVRetro\shopping-cart\html\Images\games/$y[image].jpg\" alt=\"...\" class=\"productImg\">
                </div>
                <div class=\"col-md-6\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\">$y[name] - $y[releaseYear]</h5>
                        <p class=\"card-text\">$y[price]</p>
                        <p class=\"card-text\">$y[console_consoleID] - $y[genre_genreID]</p>
                        <p class=\"card-text\">$y[description]</p>
                    </div>
                </div>
                <div class=\"col-md-1\">
                    <button  class=\"add_to_cart genre console\">Add to Cart</button>
                </div>
            </div>
        </div>
        ";

    }
}
else {
    $basicSelectResult = mysqli_query($dbc, $basicSelect);

    while ($y = mysqli_fetch_array($basicSelectResult)) {
    //var_dump($y);die();
        echo "
        <div class=\"card mb-12\ productCard\" style=\"max-width: 1400px;\">
            <div class=\"row g-0\">
                <div class=\"col-md-5\">
                    <img src=\"\FMVRetro\shopping-cart\html\Images\games/$y[image].jpg\" alt=\"...\" class=\"productImg\">
                </div>
                <div class=\"col-md-6\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\">$y[name] - $y[releaseYear]</h5>
                        <p class=\"card-text\">$y[price]</p>
                        <p class=\"card-text\">$y[console_consoleID] - $y[genre_genreID]</p>
                        <p class=\"card-text\">$y[description]</p>
                    </div>
                </div>
                <div class=\"col-md-1\">
                    <button  id=\"btn_$y[productID]\" class=\"add_to_cart\">Add to Cart</button>
                </div>
            </div>
        </div>
        ";

    } 
}
?>
<script>
function handleAddToCart(productID) {

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.open("POST", "add_to_cart.php");
        var loggedIn = <?php echo isset($_SESSION['login']) ? 1 : 0 ;?>;

        if (!loggedIn) {

            window.location.replace('http://localhost/FMVretro/shopping-cart/HTML/index.php?userLogin=true');
        }
        var userId =  <?php echo isset($_SESSION['userID']) ? $_SESSION['userID']: "''" ?>;
        var params = `product_id=${productID}&quantity=1&order_id=1&user_id=${userId}`;
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xmlhttp.send(params);
        xmlhttp.onreadystatechange = function() {
            if (this.readyState === 4 && this.status === 200) {
                console.log("res", this.responseText);
            } else {
                console.log("res", "Loading ..");
            };
        }
    }
// onclick=\"handleAddToCart($y[productID])\"
document.querySelectorAll('.add_to_cart').forEach(button => {
    button.addEventListener('click', e => {

        var id = button.id.split('_')[1];
        handleAddToCart(id);
    });
});
</script>
