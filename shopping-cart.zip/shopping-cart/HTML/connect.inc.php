<?php
/*****************************************************************************************************
 * 
 * 
 * SQL Queries
 * 
 * 
 ******************************************************************************************************/
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
//Basic SQL connection
$hostname = 'localhost';
$user = 'root';
$pswd = 'Xx4O.calxX';
$db = 'fmvretro';
$dbc = mysqli_connect($hostname, $user, $pswd, $db);

$basicSelect = "SELECT * FROM product";

// Retrieve user
//$findUser = "SELECT * FROM user WHERE userName = $username";

//Add user
//

//Add Admin user
$addAdmin = "INSERT INTO `user`(`firstName`, `lastName`, `userName`, `password`, `address`, `city`, `province`, `postalCode`, `accountStatus`, `creationDate`, `email`) VALUES ('[value-2]','[value-3]','[value-4]','[value-5]','Admin',SYSDATE(),'[value-12]')";

//Retrieve Cart e.g. the open order
//$getCart = "SELECT * FROM order WHERE user_userID = $userID AND `status` = \"OPEN\"";

//Retrieve Cart items
//$getCartItems = "SELECT * FROM cartItem WHERE order_orderID = $orderID";

//Retrieve ALL user orders
//$getOrders = "SELECT * FROM order WHERE user_userID = $userID";

//Add product
//$addProduct = "INSERT INTO product (`name`, price, `description`, `image`, stock, genre_genreID, console_consoleID) VALUES ($addProductName, $addProductPrice, $addProductDescription, $addProductImage, $addProductQty, $genreID, $consoleID)";

//Console select
$consoleList = "SELECT `consoleID`, `consoleName` FROM `console`";

//Genre select
$genreList = "SELECT * FROM genre";


//Test of basic Select -- WORKING
if (!$dbc) {
    echo "ERROR";
}
?>