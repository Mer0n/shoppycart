-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2021 at 12:52 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fmvretro`
--

-- --------------------------------------------------------

--
-- Table structure for table `cartitem`
--

CREATE TABLE `cartitem` (
  `order_orderID` int(11) NOT NULL,
  `product_productID` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `paidPrice` decimal(9,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cartitem`
--

INSERT INTO `cartitem` (`order_orderID`, `product_productID`, `quantity`, `paidPrice`) VALUES
(1, 1, 3, NULL),
(1, 2, 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `console`
--

CREATE TABLE `console` (
  `consoleID` int(11) NOT NULL,
  `consoleName` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `console`
--

INSERT INTO `console` (`consoleID`, `consoleName`) VALUES
(1, 'NES'),
(2, 'Sega Master System'),
(3, 'Sega Genesis'),
(4, 'Super Nintendo'),
(5, 'Sony PlayStation'),
(6, 'Nintendo64'),
(7, 'Sega Dreamcast'),
(8, 'Sony PlayStation 2'),
(9, 'Nintendo GameCube'),
(10, 'Sony PlayStation 3'),
(11, 'Nintendo Wii'),
(12, 'Nintendo Wii U'),
(13, 'Atari'),
(14, 'Nintendo GameBoy');

-- --------------------------------------------------------

--
-- Table structure for table `genre`
--

CREATE TABLE `genre` (
  `genreID` int(11) NOT NULL,
  `genreName` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `genre`
--

INSERT INTO `genre` (`genreID`, `genreName`) VALUES
(0, 'Fighting'),
(1, 'Action/Adventure'),
(2, 'Platformer'),
(3, 'RPG'),
(4, 'Puzzle'),
(5, 'Sports'),
(6, 'Simulation'),
(7, 'Strategy'),
(8, 'Racing'),
(9, 'Board/Card Games');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `orderID` int(11) NOT NULL,
  `user_userID` int(11) NOT NULL,
  `orderDate` date DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`orderID`, `user_userID`, `orderDate`, `status`) VALUES
(1, 1, '2021-05-24', 'OPEN');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productID` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `releaseYear` int(4) NOT NULL,
  `price` decimal(9,2) NOT NULL,
  `description` longtext NOT NULL,
  `image` varchar(45) NOT NULL,
  `stock` int(11) NOT NULL,
  `publisher` varchar(30) NOT NULL,
  `genre_genreID` int(11) NOT NULL,
  `console_consoleID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productID`, `name`, `releaseYear`, `price`, `description`, `image`, `stock`, `publisher`, `genre_genreID`, `console_consoleID`) VALUES
(1, 'Super Mario Brothers', 0, '59.50', 'The classic', 'testimg.jpg', 5, '', 1, 1),
(2, 'Final Fantasy 2(IV)', 0, '65.25', 'US Version', 'testimg2.jpg', 3, '', 3, 4),
(4, 'Ms. Pac-Man', 1981, '30.00', 'Ms. Pac-Man is a 1982 maze arcade game developed by General Computer Corporation and published by Midway. It is the first sequel to Pac-Man (1980), and the first entry in the series to not be made by Namco. Controlling the titular character, the player is tasked with eating all of the pellets in an enclosed maze while avoiding four coloured ghosts. Eating the larger “power pellets” lets the player eat the ghosts, who turn blue and flee.', 'MsPacManNES', 4, 'Namco', 1, 1),
(5, 'The Legend of Zelda: A Link To the Past', 1992, '60.00', 'The Legend of Zelda: A Link to the Past is an action-adventure game developed and published by Nintendo for the Super Nintendo Entertainment System. It is the third game in The Legend of Zelda series and was released in 1991 in Japan and 1992 in North America and Europe.\r\n\r\nA Link to the Past focuses on Link as he journeys to save Hyrule, defeat the dark lord Ganon, and rescue the descendants of the Seven Sages. It returns to a top-down perspective similar to the original The Legend of Zelda, dropping the side-scrolling gameplay of Zelda II: The Adventure of Link. It introduced series staples such as parallel worlds and items including the Master Sword. ', 'ZeldaSNES', 8, 'Nintendo', 1, 4),
(6, 'Street Fighter II', 1992, '86.75', 'Street Fighter II: The World Warrior is a competitive fighting game developed by Capcom and originally released for arcade systems in 1991. It is the second installment in the Street Fighter series and the sequel to Street Fighter, released in 1987. It prominently features a popular two-player mode that obligates direct, human-to-human competitive play which prolonged the survival of the declining video game arcade business market itself by not only stimulating business but driving the genre of similar games. Additionally, it inspired groups of competitive players to organize self-run tournament events, eventually culminating into EVO. Street Fighter II also shifted the competitive dynamic in video game arcades from one of ability to obtain the highest score, to one of ability requiring winning games directly against other human players, and other human players of large groups only possible in its two-player mode. It is Capcom\'s fourteenth title to use the CP System arcade system board. Street Fighter II improved many of the concepts introduced in the first game, including the use of special command-based moves and a six-button configuration, while offering players a wider selection of playable characters, each with their own fighting style and introducing the combo system. ', 'SF2SNES', 6, 'Capcom', 0, 4),
(7, 'Super Mario World', 1990, '55.50', 'Super Mario World is a 1990 platform game developed by Nintendo for the Super Nintendo Entertainment System (SNES). The story follows Mario\'s quest to save Princess Toadstool and Dinosaur Land from the series\' antagonist Bowser and his minions, the Koopalings. The gameplay is similar to that of earlier Super Mario games: players control Mario or his brother Luigi through a series of levels in which the goal is to reach the goalpost at the end. Super Mario World introduced Yoshi, a dinosaur who can eat enemies, as well as gain abilities by eating the shells of Koopa Troopas. ', 'SMarioWorldSNES', 12, 'Nintendo', 2, 4),
(8, 'Donkey Kong', 1986, '125.00', 'Donkey Kong is an arcade game released by Nintendo in Japan on July 9, 1981, then in North America the same month and Europe later the same year. An early example of the platform game genre, the gameplay focuses on maneuvering the main character across a series of platforms to ascend a construction site, all while avoiding or jumping over obstacles. The originally unnamed character, who was later called Jumpman, then Mario, must rescue a damsel in distress, Pauline, from the titular giant ape, Donkey Kong. The hero and ape would later become two of Nintendo\'s most popular and recognizable characters. Donkey Kong is one of the most important games from the golden age of arcade video games as well as one of the most popular arcade games of all time. ', 'DKNES', 4, 'Nintendo', 2, 1),
(9, 'Super Metroid', 1994, '210.00', 'Super Metroid is an action-adventure game developed and published by Nintendo for the Super Nintendo Entertainment System in 1994. It is the third installment in the Metroid series, following the events of the Game Boy game Metroid II: Return of Samus (1991). Players control bounty hunter Samus Aran, who travels to planet Zebes to retrieve an infant Metroid creature stolen by the Space Pirate leader Ridley.\r\n\r\nThe gameplay focuses on exploration, with the player searching for power-ups that are used to reach previously inaccessible areas. It features new concepts to the series, such as the inventory screen, an automap, and the ability to fire in all directions. The development staff from previous Metroid games—including Yoshio Sakamoto, Makoto Kano and Gunpei Yokoi—returned to develop Super Metroid over the course of two years, with half a year earlier to gain approval for the initial idea. The developers wanted to make a true action game, and to set the stage for Samus\'s reappearance. ', 'SMetroidSNES', 16, 'Nintendo', 1, 4),
(10, 'Contra', 1988, '175.50', 'Contra is a run and gun video game developed and published by Konami, originally released as a coin-operated arcade game on February 20, 1987. A home version was released for the Nintendo Entertainment System in 1988, along with ports for various computer formats, including the MSX2. The home versions were localized in the PAL region as Gryzor on the various computer formats and as Probotector on the NES, released later. Several Contra sequels were produced following the original game. ', 'ContraNES', 3, 'Konami', 1, 1),
(11, 'Final Fantasy VII', 1997, '25.00', 'Final Fantasy VII is a 1997 role-playing video game developed by Square for the PlayStation console. It is the seventh main installment in the Final Fantasy series. Published in Japan by Square, it was released in other regions by Sony Computer Entertainment and is the first in the main series with a PAL release. The game\'s story follows Cloud Strife, a mercenary who joins an eco-terrorist organization to stop a world-controlling megacorporation from using the planet\'s life essence as an energy source. Events send Cloud and his allies in pursuit of Sephiroth, a former member of the corporation who seeks to harm the planet and become a god. During the journey, Cloud builds close friendships with his party members, including Aerith Gainsborough, who holds the secret to saving their world. ', 'FFVIIPSX', 15, 'Square', 3, 5),
(16, 'Tetris', 1988, '22.50', 'In Tetris, players complete lines by moving differently shaped pieces (tetrominoes), which descend onto the playing field. The completed lines disappear and grant the player points, and the player can proceed to fill the vacated spaces. The game ends when the playing field is filled. The longer the player can delay this inevitable outcome, the higher their score will be. In multiplayer games, the players must last longer than their opponents, and in certain versions, players can inflict penalties on opponents by completing a significant number of lines. Some adaptations have provided variations to the game\'s theme, such as three-dimensional displays or a system for reserving pieces. ', 'TetrisNES', 20, 'Nintendo', 4, 1),
(17, 'Galaga', 1981, '15.00', 'Galaga is a 1981 fixed shooter arcade game developed and published by Namco. In North America, it was released by Midway Manufacturing. It is the sequel to Galaxian (1979), Namco\'s first major video game hit in arcades. Controlling a starship, the player is tasked with destroying the Galaga forces in each stage while avoiding enemies and projectiles. Some enemies can capture a player\'s ship via a tractor beam, which can be rescued to transform the player into a “dual fighter” with additional firepower. ', 'GalagaNES', 7, 'Namco', 1, 13),
(18, 'Video Olympics', 1978, '12.00', 'Video Olympics is a video game programmed by Joe Decuir for the Atari 2600. It is one of the nine 2600 launch titles Atari, Inc. published when that system was released in September 1977. The cartridge is a collection of games from Atari\'s popular arcade Pong series. A similar collection in arcade machine form called Tournament Table was published by Atari in 1978.', 'PongAtari', 5, 'Atari', 5, 13),
(19, 'Frogger', 1981, '15.00', 'Frogger is a 1981 arcade action game developed by Konami and manufactured by Sega. In North America, it was released by Sega/Gremlin. The object of the game is to direct frogs to their homes one by one by crossing a busy road and navigating a river full of hazards.\r\n\r\nFrogger was positively received as one of the greatest video games ever made and followed by several clones and sequels. By 2005, Frogger, in its various home video game incarnations, had sold 20 million copies worldwide. The game found its way into popular culture, including television and music. ', 'FroggerNES', 0, 'Sega', 2, 1),
(20, 'Kid Icarus', 1986, '125.00', 'Kid Icarus, known in Japan as A Mythology of Light: The Mirror of Palthena, is a platform game for the Family Computer Disk System in Japan and the Nintendo Entertainment System in Europe and North America. It was released in Japan in December 1986, in Europe in February 1987, and in North America in July 1987.\r\n\r\nThe plot of Kid Icarus revolves around protagonist Pit\'s quest for three sacred treasures, which he must equip to rescue the Greek-inspired fantasy world Angel Land and its ruler, the goddess Palutena. The player controls Pit through platform areas while fighting monsters and collecting items. Their objective is to reach the end of the levels, and to find and defeat boss monsters that guard the three treasures. The game was developed by Nintendo\'s Research and Development 1 division, and co-developed with Tose, who helped with additional programming. It was designed by Toru Osawa and Yoshio Sakamoto, directed by Satoru Okada, and produced by Gunpei Yokoi. ', 'KidIcarusNES', 2, 'Nintendo', 2, 1),
(21, 'Goldeneye 007', 1997, '65.25', 'GoldenEye 007 is a 1997 first-person shooter developed by Rare and published by Nintendo for the Nintendo 64. Based on the 1995 James Bond film GoldenEye, it features a single-player campaign in which the player controls Secret Intelligence Service agent James Bond through a series of levels to prevent a criminal syndicate from using a satellite weapon against London to cause a global financial meltdown. The game includes a multiplayer mode in which up to four players can compete in several deathmatch scenarios via split-screen. ', 'Goldeneye64', 30, 'Nintendo', 1, 6),
(22, 'Duck Hunt', 1984, '65.00', 'Duck Hunt is a 1984 light gun shooter video game developed and published by Nintendo for the Nintendo Entertainment System (NES) video game console. The game was first released in Japan in April 1984, followed by an arcade game port released for the Nintendo Vs. System in North America in April 1985. It was then released as a launch game for the NES in North America in October 1985, with it also releasing in Europe two years later. \r\n\r\nLIGHT GUN NOT INCLUDED', 'DuckHuntNES', 9, 'Nintendo', 5, 1),
(23, 'Excitebike', 1984, '75.00', 'Excitebike is a motocross racing video game developed and published by Nintendo. In Japan, it was released for the Famicom in 1984 and then ported to arcades as Vs. Excitebike for the Nintendo Vs. System later the same year. In North America, it was initially released for arcades in 1985 and then as a launch title for the Nintendo Entertainment System later the same year. It is the first game in the Excite series. ', 'ExciteBikeNES', 9, 'Nintendo', 8, 1),
(24, 'Gauntlet', 1988, '115.75', 'Gauntlet is a 1985 fantasy-themed hack and slash arcade game developed and released by Atari Games. It is noted as being one of the first multiplayer dungeon crawl arcade games. The core design of Gauntlet comes from 1983 Atari 8-bit dungeon crawl game Dandy, which resulted in a threat of legal action. It also bears striking similarities to the action-adventure maze game Time Bandit (1983). \r\n\r\nThe NES version was developed and published by Tengen, Atari Games\' consumer software publishing division, and was released in 1988, was the very first title to be developed in the United States for NES.', 'GauntletNES', 5, 'Tengen(Atari)', 1, 1),
(25, 'MegaMan 2', 1985, '130.00', 'Mega Man 2 (stylized as Mega Man II on title screen) is an action game developed and published by Capcom for the Nintendo Entertainment System. It was released in Japan in 1988 and in North America and PAL regions the following years. Mega Man 2 continues Mega Man\'s battle against the evil Dr. Wily and his rogue robots. It introduced graphical and gameplay changes, many of which became series staples. ', 'MM2NES', 6, 'Capcom', 2, 1),
(26, 'Space Invaders', 1980, '12.00', 'Space Invaders is a 1978 shoot \'em up arcade game developed by Tomohiro Nishikado. It was manufactured and sold by Taito in Japan, and licensed by the Midway division of Bally for overseas distribution. Within the shooter game genre, Space Invaders was the first fixed shooter and set the template for the shoot \'em up genre. The goal is to defeat wave after wave of descending aliens with a horizontally moving laser to earn as many points as possible.\r\n\r\nSpace Invaders was an immediate commercial success; by 1982, it had grossed $3.8 billion (equivalent to over $13 billion adjusted for inflation as of 2016), with a net profit of $450 million. This made it the best-selling video game and highest-grossing \"entertainment product\" at the time, and the highest-grossing video game of all time. ', 'SInvadersAtari', 14, 'Atari', 6, 13),
(27, 'Super Mario 64', 1996, '87.25', 'Super Mario 64 is a 1996 platform game for the Nintendo 64 and the first Super Mario game to feature 3D gameplay. It was developed by Nintendo EAD and published by Nintendo. As Mario, the player collects power stars while exploring Princess Peach\'s castle and must rescue her from Bowser. Super Mario 64 features open-world playability, degrees of freedom through all three axes in space, and relatively large areas which are composed primarily of true 3D polygons as opposed to only two-dimensional (2D) sprites. It emphasizes exploration within vast worlds, which require the player to complete various missions in addition to the occasional linear obstacle courses (as in traditional platform games). It preserves many gameplay elements and characters of earlier Mario games as well as the visual style. ', 'SMario64', 32, 'Nintendo', 2, 6),
(28, 'Sonic the Hedgehog 2', 1992, '15.75', 'Sonic the Hedgehog 2 is a 1992 platform game developed and published by Sega for the Sega Genesis. It follows Sonic as he attempts to stop Doctor Robotnik from stealing the Chaos Emeralds to power his space station, the Death Egg. Like the first Sonic the Hedgehog (1991), players traverse side-scrolling levels at high speeds while collecting rings and defeating enemies. Sonic 2 introduces Sonic\'s sidekick, Tails, controllable by a second player. It features faster gameplay and larger levels in comparison to the first game, in addition to a new multiplayer game mode and special stages featuring pseudo-3D graphics. The game was developed by a team of Japanese and American staff at the Sega Technical Institute (STI) in California. ', 'Sonic2Genesis', 55, 'Sega', 2, 3),
(29, 'Mortal Kombat', 1993, '23.50', 'Mortal Kombat is an arcade fighting game developed and published by Midway in 1992. It is the first entry in the Mortal Kombat series and subsequently was released by Acclaim Entertainment for nearly every home platform of the time. The game focuses on several characters of various intentions who enter a martial arts tournament with worldly consequences. It introduced many key aspects of the Mortal Kombat series, including the unique five-button control scheme and gory finishing moves called Fatalities. ', 'MKGenesis', 12, 'Midway', 0, 3),
(30, 'Mario Kart 64', 1996, '89.75', 'Mario Kart 64 is a 1996 kart racing video game developed and published by Nintendo for the Nintendo 64. It is the successor to Super Mario Kart for the Super Nintendo Entertainment System, and the second game in the Mario Kart series. It was released in Japan in December 1996, in North America in February 1997 and in the U.K. in June 1997. It was later released as a Virtual Console game for the Wii and Wii U in 2007 and 2016, respectively. ', 'MarioKart64', 9, 'Nintendo', 8, 4),
(31, 'Pokemon Red', 1998, '350.00', 'Pokémon Red Version and Pokémon Blue Version are 1996 role-playing video games developed by Game Freak and published by Nintendo for the Game Boy. They are the first installments of the Pokémon video game series. They were first released in Japan in 1996 as Pocket Monsters: Red and Pocket Monsters: Green, with the special edition Pocket Monsters: Blue being released in Japan later that same year. The games were later released as Pokémon Red and Pokémon Blue in North America and Australia in 1998 and Europe in 1999. ', 'PokemonRed', 2, 'Nintendo', 3, 14),
(32, 'Asteroids', 1979, '7.50', 'Asteroids is a space-themed multidirectional shooter arcade game designed by Lyle Rains and Ed Logg released in November 1979 by Atari, Inc. The player controls a single spaceship in an asteroid field which is periodically traversed by flying saucers. The object of the game is to shoot and destroy the asteroids and saucers, while not colliding with either, or being hit by the saucers\' counter-fire. The game becomes harder as the number of asteroids increases. ', 'AsteroidsAtari', 28, 'Atari', 1, 13);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userID` int(11) NOT NULL,
  `firstName` varchar(45) NOT NULL,
  `lastName` varchar(45) NOT NULL,
  `userName` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `province` varchar(45) NOT NULL,
  `postalCode` varchar(45) NOT NULL,
  `accountStatus` varchar(45) NOT NULL,
  `creationDate` date NOT NULL DEFAULT current_timestamp(),
  `email` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userID`, `firstName`, `lastName`, `userName`, `password`, `address`, `city`, `province`, `postalCode`, `accountStatus`, `creationDate`, `email`) VALUES
(1, 'Mike', 'Vandendorpel', 'chaosengel', 'testAccount', '3334 Painter Rd', 'Victoria', 'BC', 'V8T3V3', 'Admin', '2021-05-24', 'chaosengel@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cartitem`
--
ALTER TABLE `cartitem`
  ADD PRIMARY KEY (`order_orderID`,`product_productID`),
  ADD KEY `fk_cartItem_order1_idx` (`order_orderID`),
  ADD KEY `fk_cartItem_product1_idx` (`product_productID`);

--
-- Indexes for table `console`
--
ALTER TABLE `console`
  ADD PRIMARY KEY (`consoleID`);

--
-- Indexes for table `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`genreID`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`orderID`,`user_userID`),
  ADD KEY `fk_order_user_idx` (`user_userID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productID`,`genre_genreID`,`console_consoleID`),
  ADD KEY `fk_product_genre1_idx` (`genre_genreID`),
  ADD KEY `fk_product_console1_idx` (`console_consoleID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `console`
--
ALTER TABLE `console`
  MODIFY `consoleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `productID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cartitem`
--
ALTER TABLE `cartitem`
  ADD CONSTRAINT `fk_cartItem_order1` FOREIGN KEY (`order_orderID`) REFERENCES `order` (`orderID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cartItem_product1` FOREIGN KEY (`product_productID`) REFERENCES `product` (`productID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `fk_order_user` FOREIGN KEY (`user_userID`) REFERENCES `user` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `fk_product_console1` FOREIGN KEY (`console_consoleID`) REFERENCES `console` (`consoleID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_product_genre1` FOREIGN KEY (`genre_genreID`) REFERENCES `genre` (`genreID`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
